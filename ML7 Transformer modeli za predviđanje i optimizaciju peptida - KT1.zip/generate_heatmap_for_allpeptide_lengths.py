import csv
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt 

def attention_filename_for_hla_and_peptide(hla, peptide):
    return f"results/attention\\{hla.replace(':', '_').replace('*', '_')}_{peptide}_attention.csv"

cum_contrib_2d = np.zeros((7, 14))
cum_contrib_2d_positive = np.zeros((7, 14))
cum_contrib_2d_negative = np.zeros((7, 14))

pairs_data = pd.read_csv("1696_iedb_random_negative_pairs.csv")
# print(pairs_data)
for i in range(len(pairs_data)):
    pep = pairs_data['peptide'][i]
    hla = pairs_data['hla'][i]

    if os.path.isfile(f"./{attention_filename_for_hla_and_peptide(hla, pep)}"):
        # print(f"{attention_filename_for_hla_and_peptide(hla, pep)} exists")
        data = pd.read_csv(attention_filename_for_hla_and_peptide(hla, pep))

        if len(pep) == 8:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[0, j-1] += data.iloc[-1, j]
        
        if len(pep) == 9:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[1, j-1] += data.iloc[-1, j]
        
        if len(pep) == 10:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[2, j-1] += data.iloc[-1, j]
        
        if len(pep) == 11:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[3, j-1] += data.iloc[-1, j]
        
        if len(pep) == 12:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[4, j-1] += data.iloc[-1, j]
        
        if len(pep) == 13:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[5, j-1] += data.iloc[-1, j]
     
        if len(pep) == 14:
            for j in range(1, len(data.columns)):
                cum_contrib_2d[6, j-1] += data.iloc[-1, j]

sums = np.sum(cum_contrib_2d, -1)
normalized = cum_contrib_2d / sums[:, np.newaxis]


transphla_pairs = pd.read_csv("results/predict_results.csv")

# print(transphla_pairs)
# print(transphla_pairs['y_pred'])
for i in range(len(transphla_pairs)):
    pep = transphla_pairs['peptide'][i]
    hla = transphla_pairs['HLA'][i]
    pred = transphla_pairs['y_pred'][i]

    if pred == 1:
        # print("pred=1")
        if os.path.isfile(f"./{attention_filename_for_hla_and_peptide(hla, pep)}"):
            # print(f"{attention_filename_for_hla_and_peptide(hla, pep)} exists")
            data = pd.read_csv(attention_filename_for_hla_and_peptide(hla, pep))

            if len(pep) == 8:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[0, j-1] += data.iloc[-1, j]
            
            if len(pep) == 9:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[1, j-1] += data.iloc[-1, j]
            
            if len(pep) == 10:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[2, j-1] += data.iloc[-1, j]
            
            if len(pep) == 11:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[3, j-1] += data.iloc[-1, j]
            
            if len(pep) == 12:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[4, j-1] += data.iloc[-1, j] 
            
            if len(pep) == 13:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[5, j-1] += data.iloc[-1, j]
        
            if len(pep) == 14:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_positive[6, j-1] += data.iloc[-1, j]


    else:
        # print("pred=0")
        if os.path.isfile(f"./{attention_filename_for_hla_and_peptide(hla, pep)}"):
            # print(f"{attention_filename_for_hla_and_peptide(hla, pep)} exists")
            data = pd.read_csv(attention_filename_for_hla_and_peptide(hla, pep))

            if len(pep) == 8:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[0, j-1] += data.iloc[-1, j]
            
            if len(pep) == 9:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[1, j-1] += data.iloc[-1, j]
            
            if len(pep) == 10:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[2, j-1] += data.iloc[-1, j]
            
            if len(pep) == 11:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[3, j-1] += data.iloc[-1, j]
            
            if len(pep) == 12:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[4, j-1] += data.iloc[-1, j] 
            
            if len(pep) == 13:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[5, j-1] += data.iloc[-1, j]
        
            if len(pep) == 14:
                for j in range(1, len(data.columns)):
                    cum_contrib_2d_negative[6, j-1] += data.iloc[-1, j]

sums_neg = np.sum(cum_contrib_2d_negative, -1)
normalized_neg = cum_contrib_2d_negative / sums_neg[:, np.newaxis]

# print(cum_contrib_2d_positive)
sums_pos = np.sum(cum_contrib_2d_positive, -1)
normalized_pos = cum_contrib_2d_positive / sums_pos[:, np.newaxis]



fig, axs = plt.subplots(3, 1, figsize=(10, 15))

# First subplot
axs[0].imshow(normalized)
axs[0].set_title("All samples")
axs[0].set_xticks(range(14))
axs[0].set_xticklabels(range(1, 15))
axs[0].set_yticks(range(7))
axs[0].set_yticklabels(range(8, 15))
fig.colorbar(axs[0].imshow(normalized), ax=axs[0])

# Second subplot
axs[1].imshow(normalized_pos[:-1])
axs[1].set_title("Samples TransPHLA classified as positive")
axs[1].set_xticks(range(14))
axs[1].set_xticklabels(range(1, 15))
axs[1].set_yticks(range(6))
axs[1].set_yticklabels(range(8, 14))
fig.colorbar(axs[1].imshow(normalized_pos[:-1]), ax=axs[1])

# Third subplot
axs[2].imshow(normalized_neg)
axs[2].set_title("Samples TransPHLA classified as negative")
axs[2].set_xticks(range(14))
axs[2].set_xticklabels(range(1, 15))
axs[2].set_yticks(range(7))
axs[2].set_yticklabels(range(8, 15))
fig.colorbar(axs[2].imshow(normalized_neg), ax=axs[2])

# Adjust layout to prevent overlap
plt.subplots_adjust(hspace=0.4)
# Display the plots
plt.show()
